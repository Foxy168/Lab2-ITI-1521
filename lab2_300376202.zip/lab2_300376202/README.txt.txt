Nom d'etudiant(e): Mohamed Boudabbous
Numero d'etudiant: 300376202
Code de cours: ITI1521
Section de lab: B02

Cette archive contient les 3 fichiers du laboratoire 2, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Combination.java et DoorLock.java.